import React from 'react'
import FormSignup from './FormSignup'

const Form = () => {
    return (
        <div>
            <FormSignup/>
        </div>
    )
}

export default Form